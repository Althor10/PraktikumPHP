-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2022 at 12:24 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `praktikumphp1`
--

-- --------------------------------------------------------

--
-- Table structure for table `pp_hostingplan`
--

CREATE TABLE `pp_hostingplan` (
  `id` int(6) NOT NULL,
  `hosting_id` int(6) NOT NULL,
  `hosting_plan_id` int(6) NOT NULL,
  `per_month` varchar(555) COLLATE utf8_bin NOT NULL,
  `size` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `pp_hostings`
--

CREATE TABLE `pp_hostings` (
  `id` int(6) NOT NULL,
  `hosting_name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `pp_images`
--

CREATE TABLE `pp_images` (
  `id` int(6) NOT NULL,
  `img_alt` varchar(255) COLLATE utf8_bin NOT NULL,
  `img_path` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_images`
--

INSERT INTO `pp_images` (`id`, `img_alt`, `img_path`) VALUES
(1, 'digital-marketing', 'assets/images/digital-marketing.jpg'),
(2, 'webdesign-dev', 'assets/images/web-design.jpg'),
(3, 'web-hosting', 'assets/images/web-hosting.jpg'),
(4, 'Sponser', 'assets/images/sponser.png'),
(5, 'bearbrand', 'assets/images/bearbrand.jpg'),
(6, 'designer', 'assets/images/designer.jpg'),
(7, 'mountain', 'assets/images/mountain.jpg'),
(8, 'brandname', 'assets/images/brandname.jpg'),
(9, 'stores', 'assets/images/stores.jpg'),
(10, 'hipster', 'assets/images/hipster.jpg'),
(11, 'site-logo1', 'assets/images/ds-logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `pp_letters`
--

CREATE TABLE `pp_letters` (
  `id` int(6) NOT NULL,
  `email` varchar(1000) COLLATE utf8_bin NOT NULL,
  `firstname` varchar(255) COLLATE utf8_bin NOT NULL,
  `lastname` varchar(255) COLLATE utf8_bin NOT NULL,
  `message` varchar(2000) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `pp_nav`
--

CREATE TABLE `pp_nav` (
  `id` int(6) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `sub` int(6) NOT NULL,
  `adm` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_nav`
--

INSERT INTO `pp_nav` (`id`, `name`, `path`, `sub`, `adm`) VALUES
(1, 'Our digital services', '#Services', 1, 0),
(2, 'Our Work', '#OurWork', 1, 0),
(3, 'Testimonials', '#Testimonials', 1, 0),
(4, 'Contact', '#Contact', 1, 0),
(5, 'Dashboard', '?page=admin', 0, 1),
(6, 'Products', '?page=products', 0, 1),
(7, 'Account', '?page=account', 0, 1),
(8, 'Settings', '?page=settings', 0, 1),
(10, 'Login', '?page=admin', 0, 0),
(11, 'Logout', '?page=logout', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pp_plan`
--

CREATE TABLE `pp_plan` (
  `id` int(6) NOT NULL,
  `plan_name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `pp_role`
--

CREATE TABLE `pp_role` (
  `id` int(6) NOT NULL,
  `role_name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_role`
--

INSERT INTO `pp_role` (`id`, `role_name`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `pp_services`
--

CREATE TABLE `pp_services` (
  `id` int(6) NOT NULL,
  `img_id` int(6) NOT NULL,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `service_desc` varchar(2500) COLLATE utf8_bin NOT NULL,
  `service_name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_services`
--

INSERT INTO `pp_services` (`id`, `img_id`, `path`, `service_desc`, `service_name`) VALUES
(1, 1, 'digital-marketing', 'At a high level, digital marketing refers to advertising delivered through digital channels such as search engines, websites, social media, email, and mobile apps. While this term covers a wide range of marketing activities, all of which are not universally agreed upon, we’ll focus on the most common types below.', 'Digital Marketing\r\n'),
(2, 2, 'web-dev', 'For businesses today, it’s not just about having a website. It\'s about having an effective, multifunctional portal that plays a crucial marketing role. Whether your business is B2B, B2C or both, your website should spearhead your Demand Acceleration by inviting, informing and engaging your target audience.', 'Webdesign & Development'),
(3, 3, 'web-hosting', 'Web hosting is a service that allows organizations and individuals to post a website or web page onto the Internet. A web host, or web hosting service provider, is a business that provides the technologies and services needed for the website or webpage to be viewed in the Internet.', 'Web Hosting');

-- --------------------------------------------------------

--
-- Table structure for table `pp_social`
--

CREATE TABLE `pp_social` (
  `id` int(6) NOT NULL,
  `url` varchar(255) COLLATE utf8_bin NOT NULL,
  `icon` varchar(1000) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_social`
--

INSERT INTO `pp_social` (`id`, `url`, `icon`) VALUES
(1, 'https://www.facebook.com/danilo.zdravkovic.127', 'fa fa-facebook'),
(2, 'https://www.linkedin.com/in/danilo-zdravkovi%C4%87-2ba717168/', 'fa fa-linkedin');

-- --------------------------------------------------------

--
-- Table structure for table `pp_sponsors`
--

CREATE TABLE `pp_sponsors` (
  `id` int(6) NOT NULL,
  `img_id` int(6) NOT NULL,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `sponsor_name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_sponsors`
--

INSERT INTO `pp_sponsors` (`id`, `img_id`, `path`, `sponsor_name`) VALUES
(2, 5, '#', 'bearbrand'),
(3, 6, '#', 'Designer'),
(4, 7, '#', 'Mountain'),
(5, 8, '#', 'Brandname'),
(6, 9, '#', 'Stores'),
(7, 10, '#', 'Hipster');

-- --------------------------------------------------------

--
-- Table structure for table `pp_testimonials`
--

CREATE TABLE `pp_testimonials` (
  `id` int(6) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `ocupation` varchar(255) COLLATE utf8_bin NOT NULL,
  `testimonial` varchar(2000) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_testimonials`
--

INSERT INTO `pp_testimonials` (`id`, `name`, `ocupation`, `testimonial`) VALUES
(1, 'Emma', 'President and General Manager', 'I\'m thrilled with the new website that Position2 developed for Janrain to reflect our evolution into the leading provider of enterprise customer identity and access management solutions.'),
(2, 'Jeff', 'Chief Commercial Officer', 'From a metrics perspective, the amount of efficiency we\'ve been able to wring from the Position2 PPC channel in the face of really interesting challenges has been phenomenal.');

-- --------------------------------------------------------

--
-- Table structure for table `pp_users`
--

CREATE TABLE `pp_users` (
  `id` int(6) NOT NULL,
  `fullName` varchar(600) COLLATE utf8_bin NOT NULL,
  `passwd` varchar(2000) COLLATE utf8_bin NOT NULL,
  `usernm` varchar(255) COLLATE utf8_bin NOT NULL,
  `role_id` int(6) NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_users`
--

INSERT INTO `pp_users` (`id`, `fullName`, `passwd`, `usernm`, `role_id`, `email`) VALUES
(1, 'dz22716', '90c879c291bb0b2ee149c3f60ab0188a', 'dz22716', 1, 'danilo.zdravkovic.227.16@ict.edu.rs');

-- --------------------------------------------------------

--
-- Table structure for table `pp_webhosting`
--

CREATE TABLE `pp_webhosting` (
  `id` int(6) NOT NULL,
  `hosting_id` int(6) NOT NULL,
  `owner_id` int(6) NOT NULL,
  `URL` varchar(400) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pp_hostingplan`
--
ALTER TABLE `pp_hostingplan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hosting_id` (`hosting_id`),
  ADD KEY `hosting_plan_id` (`hosting_plan_id`);

--
-- Indexes for table `pp_hostings`
--
ALTER TABLE `pp_hostings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_images`
--
ALTER TABLE `pp_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_letters`
--
ALTER TABLE `pp_letters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_nav`
--
ALTER TABLE `pp_nav`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub` (`sub`);

--
-- Indexes for table `pp_plan`
--
ALTER TABLE `pp_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_role`
--
ALTER TABLE `pp_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_services`
--
ALTER TABLE `pp_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `img_id` (`img_id`);

--
-- Indexes for table `pp_social`
--
ALTER TABLE `pp_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_sponsors`
--
ALTER TABLE `pp_sponsors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `img_id` (`img_id`);

--
-- Indexes for table `pp_testimonials`
--
ALTER TABLE `pp_testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_users`
--
ALTER TABLE `pp_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `pp_webhosting`
--
ALTER TABLE `pp_webhosting`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `URL` (`URL`),
  ADD KEY `hosting_id` (`hosting_id`),
  ADD KEY `owner_id` (`owner_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pp_hostingplan`
--
ALTER TABLE `pp_hostingplan`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pp_hostings`
--
ALTER TABLE `pp_hostings`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pp_images`
--
ALTER TABLE `pp_images`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pp_letters`
--
ALTER TABLE `pp_letters`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pp_nav`
--
ALTER TABLE `pp_nav`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pp_plan`
--
ALTER TABLE `pp_plan`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pp_role`
--
ALTER TABLE `pp_role`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pp_services`
--
ALTER TABLE `pp_services`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pp_social`
--
ALTER TABLE `pp_social`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pp_sponsors`
--
ALTER TABLE `pp_sponsors`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pp_testimonials`
--
ALTER TABLE `pp_testimonials`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pp_users`
--
ALTER TABLE `pp_users`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pp_webhosting`
--
ALTER TABLE `pp_webhosting`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

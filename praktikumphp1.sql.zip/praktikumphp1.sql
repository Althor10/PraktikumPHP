-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2022 at 02:29 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `praktikumphp1`
--

-- --------------------------------------------------------

--
-- Table structure for table `pp_devwork`
--

CREATE TABLE `pp_devwork` (
  `id` int(6) NOT NULL,
  `server_id` int(6) NOT NULL,
  `request` varchar(2000) COLLATE utf8_bin NOT NULL,
  `assign_id` int(6) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_devwork`
--

INSERT INTO `pp_devwork` (`id`, `server_id`, `request`, `assign_id`, `status`) VALUES
(1, 1, 'Test ', 1, 1),
(2, 2, 'We want to see if this form works pls.', 1, 0),
(3, 2, 'Test3', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pp_hostings`
--

CREATE TABLE `pp_hostings` (
  `id` int(6) NOT NULL,
  `hosting_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `sizeMB` int(10) NOT NULL,
  `bandwidth` int(3) NOT NULL,
  `SSLtrue` tinyint(1) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_bin NOT NULL,
  `SEOTools` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_hostings`
--

INSERT INTO `pp_hostings` (`id`, `hosting_name`, `sizeMB`, `bandwidth`, `SSLtrue`, `description`, `SEOTools`) VALUES
(1, 'Managed Hosting', 10240, 50, 1, 'Our standard Managed Hosting, for your website. With limited size and a bandwidth. This Hosting, doesn\'t include SEOTools however, we do offer our services for any help you may need. We recommend this hosting for a small website.', 0),
(2, 'Shared Hosting', 51200, 50, 1, 'Shared hosting has a much larger space, however, compared to our PRO hosting doesn\'t have that high of a bandwidth. We recommend this if you have more than 1 smaller website.', 0),
(3, 'cPanel', 51200, 100, 1, 'Our best offer. This hosting gets the best of our servers regarding speed and size. We recommend this hosting for professional websites and projects.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pp_images`
--

CREATE TABLE `pp_images` (
  `id` int(6) NOT NULL,
  `img_alt` varchar(255) COLLATE utf8_bin NOT NULL,
  `img_path` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_images`
--

INSERT INTO `pp_images` (`id`, `img_alt`, `img_path`) VALUES
(1, 'digital-marketing', 'assets/images/digital-marketing.jpg'),
(2, 'webdesign-dev', 'assets/images/web-design.jpg'),
(3, 'web-hosting', 'assets/images/web-hosting.jpg'),
(4, 'Sponser', 'assets/images/sponser.png'),
(5, 'bearbrand', 'assets/images/bearbrand.jpg'),
(6, 'designer', 'assets/images/designer.jpg'),
(7, 'mountain', 'assets/images/mountain.jpg'),
(8, 'brandname', 'assets/images/brandname.jpg'),
(9, 'stores', 'assets/images/stores.jpg'),
(10, 'hipster', 'assets/images/hipster.jpg'),
(11, 'site-logo1', 'assets/images/ds-logo.png'),
(12, 'author', 'assets/img/author.png'),
(13, 'profile', 'assets/img/profilePics/profile.png'),
(14, 'admin_profile', 'assets/img/profilePics/rsz_author.png');

-- --------------------------------------------------------

--
-- Table structure for table `pp_nav`
--

CREATE TABLE `pp_nav` (
  `id` int(6) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `sub` int(6) NOT NULL,
  `adm` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_nav`
--

INSERT INTO `pp_nav` (`id`, `name`, `path`, `sub`, `adm`) VALUES
(1, 'Our digital services', '#Services', 1, 0),
(2, 'Our Work', '#OurWork', 1, 0),
(3, 'Testimonials', '#Testimonials', 1, 0),
(4, 'Contact', '#Contact', 1, 0),
(5, 'Dashboard', '?page=admin', 0, 1),
(6, 'Servers', '?page=admin&subpage=servers', 0, 1),
(7, 'Account', '?page=admin&subpage=account', 0, 1),
(8, 'About Author', '?page=author', 0, 0),
(10, 'Login', '?page=admin', 0, 0),
(11, 'Server', '?page=admin&subpage=serverStatus', 0, 1),
(12, 'Home', '?page=home', 0, 0),
(13, 'Logout', '?page=logout', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pp_payment`
--

CREATE TABLE `pp_payment` (
  `id` int(6) NOT NULL,
  `user_id` int(6) NOT NULL,
  `server_id` int(6) NOT NULL,
  `paymentDate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_payment`
--

INSERT INTO `pp_payment` (`id`, `user_id`, `server_id`, `paymentDate`) VALUES
(1, 2, 1, '2022-05-18 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pp_plan`
--

CREATE TABLE `pp_plan` (
  `id` int(6) NOT NULL,
  `plan_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `hosting_id` int(6) NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `perMonth` decimal(3,2) NOT NULL,
  `sale` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_plan`
--

INSERT INTO `pp_plan` (`id`, `plan_name`, `hosting_id`, `description`, `perMonth`, `sale`) VALUES
(2, 'Basic Plan', 1, 'Our Basic plan. Containing our Managed Hosting. ', '2.15', 0),
(3, 'Standard Plan', 2, 'Our Standard Plan containing our Shared Hosting', '3.20', 0),
(4, 'PRO plan', 3, 'Our PRO plan. Containing our cPanel Hosting.', '5.15', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pp_role`
--

CREATE TABLE `pp_role` (
  `id` int(6) NOT NULL,
  `role_name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_role`
--

INSERT INTO `pp_role` (`id`, `role_name`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `pp_server`
--

CREATE TABLE `pp_server` (
  `id` int(6) NOT NULL,
  `user_id` int(6) NOT NULL,
  `plan_id` int(6) NOT NULL,
  `occupiedSizeOnServer` int(11) NOT NULL DEFAULT 0,
  `serverUrl` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'http://myfirstwebsite',
  `ipAddress` varchar(15) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_server`
--

INSERT INTO `pp_server` (`id`, `user_id`, `plan_id`, `occupiedSizeOnServer`, `serverUrl`, `ipAddress`) VALUES
(1, 2, 3, 2000, 'http://newsrv.com', '172.130.30.20'),
(2, 1, 2, 0, 'http://myserver1.com', '252.138.62');

-- --------------------------------------------------------

--
-- Table structure for table `pp_services`
--

CREATE TABLE `pp_services` (
  `id` int(6) NOT NULL,
  `img_id` int(6) NOT NULL,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `service_desc` varchar(2500) COLLATE utf8_bin NOT NULL,
  `service_name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_services`
--

INSERT INTO `pp_services` (`id`, `img_id`, `path`, `service_desc`, `service_name`) VALUES
(1, 1, 'digital-marketing', 'At a high level, digital marketing refers to advertising delivered through digital channels such as search engines, websites, social media, email, and mobile apps. While this term covers a wide range of marketing activities, all of which are not universally agreed upon, we’ll focus on the most common types below.', 'Digital Marketing\r\n'),
(2, 2, 'web-dev', 'For businesses today, it’s not just about having a website. It\'s about having an effective, multifunctional portal that plays a crucial marketing role. Whether your business is B2B, B2C or both, your website should spearhead your Demand Acceleration by inviting, informing and engaging your target audience.', 'Webdesign & Development'),
(3, 3, 'web-hosting', 'Web hosting is a service that allows organizations and individuals to post a website or web page onto the Internet. A web host, or web hosting service provider, is a business that provides the technologies and services needed for the website or webpage to be viewed in the Internet.', 'Web Hosting');

-- --------------------------------------------------------

--
-- Table structure for table `pp_social`
--

CREATE TABLE `pp_social` (
  `id` int(6) NOT NULL,
  `url` varchar(255) COLLATE utf8_bin NOT NULL,
  `icon` varchar(1000) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_social`
--

INSERT INTO `pp_social` (`id`, `url`, `icon`) VALUES
(1, 'https://www.facebook.com/danilo.zdravkovic.127', 'fa fa-facebook'),
(2, 'https://www.linkedin.com/in/danilo-zdravkovi%C4%87-2ba717168/', 'fa fa-linkedin');

-- --------------------------------------------------------

--
-- Table structure for table `pp_sponsors`
--

CREATE TABLE `pp_sponsors` (
  `id` int(6) NOT NULL,
  `img_id` int(6) NOT NULL,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `sponsor_name` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_sponsors`
--

INSERT INTO `pp_sponsors` (`id`, `img_id`, `path`, `sponsor_name`) VALUES
(2, 5, '#', 'bearbrand'),
(3, 6, '#', 'Designer'),
(4, 7, '#', 'Mountain'),
(5, 8, '#', 'Brandname'),
(6, 9, '#', 'Stores'),
(7, 10, '#', 'Hipster');

-- --------------------------------------------------------

--
-- Table structure for table `pp_testimonials`
--

CREATE TABLE `pp_testimonials` (
  `id` int(6) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `ocupation` varchar(255) COLLATE utf8_bin NOT NULL,
  `testimonial` varchar(2000) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_testimonials`
--

INSERT INTO `pp_testimonials` (`id`, `name`, `ocupation`, `testimonial`) VALUES
(1, 'Emma', 'President and General Manager', 'I\'m thrilled with the new website that Position2 developed for Janrain to reflect our evolution into the leading provider of enterprise customer identity and access management solutions.'),
(2, 'Jeff', 'Chief Commercial Officer', 'From a metrics perspective, the amount of efficiency we\'ve been able to wring from the Position2 PPC channel in the face of really interesting challenges has been phenomenal.');

-- --------------------------------------------------------

--
-- Table structure for table `pp_users`
--

CREATE TABLE `pp_users` (
  `id` int(6) NOT NULL,
  `firstName` varchar(600) COLLATE utf8_bin NOT NULL,
  `lastName` varchar(500) COLLATE utf8_bin NOT NULL,
  `passwd` varchar(2000) COLLATE utf8_bin NOT NULL,
  `usernm` varchar(255) COLLATE utf8_bin NOT NULL,
  `role_id` int(6) NOT NULL DEFAULT 2,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `memberFrom` datetime NOT NULL DEFAULT current_timestamp(),
  `dev` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_users`
--

INSERT INTO `pp_users` (`id`, `firstName`, `lastName`, `passwd`, `usernm`, `role_id`, `email`, `memberFrom`, `dev`) VALUES
(1, 'Danilo', 'Zdravkovic', '90c879c291bb0b2ee149c3f60ab0188a', 'dz22716', 1, 'danilo.zdravkovic.227.16@ict.edu.rs', '2022-04-29 00:00:00', 1),
(2, 'Abdul', 'Abadwaea', '90c879c291bb0b2ee149c3f60ab0188a', 'testUser1', 2, 'testUser1@gmail.com', '2022-04-29 21:03:28', 1),
(3, 'Testing', 'Thisfnform', '90c879c291bb0b2ee149c3f60ab0188a', 'testUser2', 2, 'testUser2@gmail.com', '2022-04-29 21:06:25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pp_user_img`
--

CREATE TABLE `pp_user_img` (
  `id` int(6) NOT NULL,
  `user_id` int(6) NOT NULL,
  `img_id` int(6) NOT NULL DEFAULT 13
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `pp_user_img`
--

INSERT INTO `pp_user_img` (`id`, `user_id`, `img_id`) VALUES
(1, 1, 14),
(2, 2, 13),
(3, 3, 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pp_devwork`
--
ALTER TABLE `pp_devwork`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`server_id`),
  ADD KEY `assign_id` (`assign_id`);

--
-- Indexes for table `pp_hostings`
--
ALTER TABLE `pp_hostings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_images`
--
ALTER TABLE `pp_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_nav`
--
ALTER TABLE `pp_nav`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub` (`sub`);

--
-- Indexes for table `pp_payment`
--
ALTER TABLE `pp_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `server_id` (`server_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pp_plan`
--
ALTER TABLE `pp_plan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hosting_id` (`hosting_id`);

--
-- Indexes for table `pp_role`
--
ALTER TABLE `pp_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_server`
--
ALTER TABLE `pp_server`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ipAddress` (`ipAddress`),
  ADD UNIQUE KEY `serverUrl` (`serverUrl`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `plan_id` (`plan_id`);

--
-- Indexes for table `pp_services`
--
ALTER TABLE `pp_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `img_id` (`img_id`);

--
-- Indexes for table `pp_social`
--
ALTER TABLE `pp_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_sponsors`
--
ALTER TABLE `pp_sponsors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `img_id` (`img_id`);

--
-- Indexes for table `pp_testimonials`
--
ALTER TABLE `pp_testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pp_users`
--
ALTER TABLE `pp_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `usernm` (`usernm`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `pp_user_img`
--
ALTER TABLE `pp_user_img`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `img_id` (`img_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pp_devwork`
--
ALTER TABLE `pp_devwork`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pp_hostings`
--
ALTER TABLE `pp_hostings`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pp_images`
--
ALTER TABLE `pp_images`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `pp_nav`
--
ALTER TABLE `pp_nav`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `pp_payment`
--
ALTER TABLE `pp_payment`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pp_plan`
--
ALTER TABLE `pp_plan`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pp_role`
--
ALTER TABLE `pp_role`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pp_server`
--
ALTER TABLE `pp_server`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pp_services`
--
ALTER TABLE `pp_services`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pp_social`
--
ALTER TABLE `pp_social`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pp_sponsors`
--
ALTER TABLE `pp_sponsors`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pp_testimonials`
--
ALTER TABLE `pp_testimonials`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pp_users`
--
ALTER TABLE `pp_users`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pp_user_img`
--
ALTER TABLE `pp_user_img`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pp_devwork`
--
ALTER TABLE `pp_devwork`
  ADD CONSTRAINT `pp_devwork_ibfk_1` FOREIGN KEY (`server_id`) REFERENCES `pp_server` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pp_devwork_ibfk_2` FOREIGN KEY (`assign_id`) REFERENCES `pp_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pp_payment`
--
ALTER TABLE `pp_payment`
  ADD CONSTRAINT `pp_payment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `pp_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pp_payment_ibfk_2` FOREIGN KEY (`server_id`) REFERENCES `pp_server` (`id`);

--
-- Constraints for table `pp_plan`
--
ALTER TABLE `pp_plan`
  ADD CONSTRAINT `pp_plan_ibfk_1` FOREIGN KEY (`hosting_id`) REFERENCES `pp_hostings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pp_server`
--
ALTER TABLE `pp_server`
  ADD CONSTRAINT `pp_server_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `pp_plan` (`id`),
  ADD CONSTRAINT `pp_server_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `pp_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pp_services`
--
ALTER TABLE `pp_services`
  ADD CONSTRAINT `pp_services_ibfk_1` FOREIGN KEY (`img_id`) REFERENCES `pp_images` (`id`);

--
-- Constraints for table `pp_sponsors`
--
ALTER TABLE `pp_sponsors`
  ADD CONSTRAINT `pp_sponsors_ibfk_1` FOREIGN KEY (`img_id`) REFERENCES `pp_images` (`id`);

--
-- Constraints for table `pp_users`
--
ALTER TABLE `pp_users`
  ADD CONSTRAINT `pp_users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `pp_role` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
